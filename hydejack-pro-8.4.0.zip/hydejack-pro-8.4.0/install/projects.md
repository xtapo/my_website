---
layout: projects
title: Projects
show_collection: projects
description: >
  This is a demo of the `projects` layout, which is included in the PRO version of Hydejack.
last_modified_at: 2018-08-03
---
