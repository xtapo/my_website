---
layout: resume
title: Résumé*
description: >
  This is the `description` of your resume page, as it will be seen by search engines.
  Open `resume.md` to edit this text.
hide_description: false
menu: true
order: 3
left_column:
 - work
 - volunteer
 - education
 - awards
 - publications
 - references
right_column:
 - languages
 - skills
 - interests
---
